﻿#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#include <iostream>
#include <list>
#include<iterator>
using namespace std;
struct Leaks {
    ~Leaks() { _CrtDumpMemoryLeaks(); }
}_l;

struct Wrong_element_exeptinon{ /*int elem = 0;*/ };

int random_value_generator() {//to the template?
    static int necto = 0;
    necto += 1;
    return (necto % 100);
}

class Zemtseva {
public:
    int* inf0 = new int(random_value_generator());
    Zemtseva() {};
    //virtual void change(int a) = 0;
    virtual bool should_be_copied() { return true; };
    virtual void print() { cout << *inf0; };
    virtual Zemtseva* copy() { return new Zemtseva(*this);};
    Zemtseva(Zemtseva& obj_for_copy) : inf0(new int) { *inf0 = *obj_for_copy.inf0;}
    virtual ~Zemtseva() { delete inf0; };
};

class Zemtseva_1: public Zemtseva{
    list<int*>* inf11 = new list<int*>;
    char inf12[10] = "something";
    void change(int a = 16) { (*inf11).push_back(&a); };//нереализ.
public:
    Zemtseva_1() {};
    virtual Zemtseva* copy() { return new Zemtseva(*this); };
    //Zemtseva_1(const Zemtseva_1& obj_for_copy) {};
    //virtual bool should_be_copied() { return true; };
    void print() {
        for (list<int*>::iterator it = (*inf11).begin(); it != (*inf11).end(); ++it) {
            cout << *it << " ";
        };
        cout << inf12;
    };
    ~Zemtseva_1() { delete inf11; };
};

class Zemtseva_2: public Zemtseva_1{
    float* inf2 = new float(random_value_generator());
public:
    Zemtseva_2() {};
    virtual Zemtseva* copy() { throw Wrong_element_exeptinon();};
    //Zemtseva_2(const Zemtseva_2& obj_for_copy){}
    //virtual bool should_be_copied() { return false; };//Zemtseva* copy() { return new Zemtseva_2(*this); };
    void print() {
        cout << *inf2 << '\t';
    };
    ~Zemtseva_2() { delete inf2; };
};

class Zemtseva_3: public Zemtseva_2 {
    double* inf3 = new double(19.03);
public:
    Zemtseva_3() {};
    virtual Zemtseva* copy() { throw Wrong_element_exeptinon();};
    //Zemtseva_3(const Zemtseva_3& obj_for_copy) {}
    //virtual bool should_be_copied() { return false; };//Zemtseva* copy() { return new Zemtseva_3(*this); };
    void print() {
        cout << *inf3 << '\t';
    };
    ~Zemtseva_3() { delete inf3; };
};

class DB {
private:
    list<Zemtseva*> ourdata;
public:
    void adding(Zemtseva* obj) {
        ourdata.push_back(obj);
    }
    void change(Zemtseva* obj, int num) {
        if (ourdata.size() >= num) {
            int counter = 0;
            for (list<Zemtseva*>::iterator it = ourdata.begin(); it != ourdata.end(); ++it) {
                if (counter == num) {//if? можно менять первый~
                    ourdata.insert(it, obj);
                    delete (*it);
                    ourdata.erase(it);
                    break;
                }
                counter += 1;
            };
        };
    }
    DB& operator=( DB& obj) {
        if ((*this).ourdata.size() > 0) {
            for (list<Zemtseva*>::iterator it = ourdata.begin(); it != ourdata.end(); ++it) {
                delete (*it);
            }
            this->ourdata.clear();
        };
        for (list<Zemtseva*>::iterator it = (obj.ourdata).begin(); it != obj.ourdata.end(); ++it) {
            try { this->ourdata.emplace_back((*it)->copy()); }//emplase/push?
            catch (...) { continue; }
        }
        return *this;
    };
    void print() {
        for (list<Zemtseva*>::iterator it = ourdata.begin(); it != ourdata.end(); ++it) {
            (*it)->print();
            cout << '\t';
        }
        cout << endl;
    };
    ~DB() {
        for (list<Zemtseva*>::iterator it = ourdata.begin(); it != ourdata.end(); ++it) {
            delete *(it); 
        };
    }
};

int main()
{
    DB db1, db2;
    Zemtseva* a1 = new Zemtseva_1;
    Zemtseva* a2 = new Zemtseva_2;
    Zemtseva* a3 = new Zemtseva_3;
    Zemtseva* b1 = new Zemtseva_1;
    Zemtseva* c1 = new Zemtseva_1;
    Zemtseva* b2 = new Zemtseva_2;
    Zemtseva* c2 = new Zemtseva_2;
    Zemtseva* b3 = new Zemtseva_3;
    Zemtseva* c3 = new Zemtseva_3;
    db1.adding(a1);
    db1.adding(a2);
    db1.adding(a3);
    db2.adding(b1);
    db2.adding(b2);
    db2.adding(b3);
    db2.adding(c1);
    db2.adding(c2);
    db2.adding(c3);

    Zemtseva* a5 = new Zemtseva_1;//db1.print();
    db1.change(a5, 1);
    //Zemtseva* a6 = new Zemtseva_2;//1;
    //db1.adding(a6);
    db2 = db1;
    db1.print();
    db2.print();
    return 0;
}
